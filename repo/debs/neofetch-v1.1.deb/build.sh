#!/bin/bash
# build-deb.sh

APP_NAME="neofetch"
VERSION="1.0"
ARCH="iphoneos-arm"
MAINTAINER="tuanem"
DESCRIPTION="NeoFetch for iOS 4/5/6"

WORKDIR="$PWD/${APP_NAME}-deb"

# Xóa folder cũ
rm -rf "$WORKDIR"

# Tạo cấu trúc thư mục
mkdir -p "$WORKDIR/DEBIAN"
mkdir -p "$WORKDIR/usr/bin"

# Copy file thực thi vào usr/bin
cp "$PWD/$APP_NAME" "$WORKDIR/usr/bin/$APP_NAME"
chmod +x "$WORKDIR/usr/bin/$APP_NAME"

# Tạo file control
cat <<EOF > "$WORKDIR/DEBIAN/control"
Package: com.tuanem.neofetch
Name: $APP_NAME
Version: $VERSION
Architecture: $ARCH
Maintainer: $MAINTAINER
Description: $DESCRIPTION
Section: System
Priority: optional
Depends: bash
EOF

# Build deb, dùng gzip
dpkg-deb -Zgzip --build "$WORKDIR" "${APP_NAME}.deb"

echo "Built ${APP_NAME}.deb with gzip compression for iOS"
